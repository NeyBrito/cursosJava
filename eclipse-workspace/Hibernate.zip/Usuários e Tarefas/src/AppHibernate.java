
public class AppHibernate {

	public static void main(String[] args) {

		/**
		 * Adicionando registros
		 */

		
		/**
		 * Recuperando informa��es sobre um dos usu�rios
		 */


		/**
		 * Atualizando o registro de Anakin Skywalker
		 * ap�s passar para o lado negro da for�a
		 */
		
		/**
		 * Atualiza��o parcial de um registro
		 */

		
		/**
		 * Apagando o registro de Padm�
		 * ap�s sua morte durante o parto
		 */
		
		System.exit(0);
	}

}